import MediaProgressbar from "@/components/media-progress-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { InstructorContext } from "@/context/instructor-context";
import { mediaUploadService } from "@/services";
import { useContext } from "react";

function CourseSettings() {
  const {
    courseLandingFormData,
    setCourseLandingFormData,
    mediaUploadProgress,
    setMediaUploadProgress,
    mediaUploadProgressPercentage,
    setMediaUploadProgressPercentage,
  } = useContext(InstructorContext);

  async function handleImageUploadChange(event) {
    const selectedImage = event.target.files[0];

    if (selectedImage) {
      const imageFormData = new FormData();
      imageFormData.append("file", selectedImage);

      try {
        setMediaUploadProgress(true);
        // const response = await mediaUploadService(
        //   imageFormData,
        //   setMediaUploadProgressPercentage
        // );
        if (true || response.success) {
          setCourseLandingFormData({
            ...courseLandingFormData,
            // image: response.data.url,
            image: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAADBAACBQEGBwj/xAA3EAACAgEDAgUDAgMGBwAAAAABAgADEQQSIQUxBiJBUWETcYEUMiNCkSRDUmKxwRWhotHh8PH/xAAZAQADAQEBAAAAAAAAAAAAAAAAAgMEAQX/xAAkEQACAgICAQQDAQAAAAAAAAAAAQIRAyESMRMEMkFRIkJhUv/aAAwDAQACEQMRAD8A916SBpWs5EhjihAczsGp5xLzoHczmZzOTxFrdbUlop3D6h/lzFlJR7GjFvobyINrVXgmctdUUf4viLvS7DkCQlm/yVjhv3DDahF78D3kNgIyD3mbYhPlB2sBg8wKam6kebsO+4yS9S09lH6ZVo1CZDBU2i5eBhh3EjvgTTDIpq0Z5QcXslr4EqHC9+0EX3GRjGsUJuLHiGrGBkwNQxzLPcqjuJ0AzWADmcVtxye0QOoNrhVMcHChfXELCgu+SdXtOToEXKn4heCINbEPc4nQeeDmBwjDHIllbgZnCR2JE4O/BEAMjxNrRpdFhbCtj8KB3P8A4mH4Y/teqJt3Mvr6kwHisvd1baX4QDj/AN+Zu+CtEU0v1Xx5+PxPNk/Jlo9CK8eKzcL6PTUNZYyqEBOWPpMzpfibpfWNQ9PT7C7VthhtI9cf7GafWdBV1HR3aW0kVtWVJX0nl/CXhodEtbV322WXNkLu4IUkkk44zky0tE42ze6gVquOCMEcwFlSrStlq5yeCfeFvsW2wluQBPP+JvGOi6Zrk0tqsyVhS+1c7SRkSHHk2VukaQdq7gUYBhyBn9wmls/U070Ybpm/Up6ppatTpNrq6hkYDjPv+YYa2vT9Ca5wN9IJKsOWA9vmGJ8GGRckjitgkH0MsXGe8Dbqq9XpV1VZ7d+fSKm0nma4ZFJaMc8bi9jtmpKjgxZnexuTxBZyeYVDzGuxKHdHWo5jIbdZA1eSv5MLT3zKIBtP2yTq9pIwtkatGg2pHpOq/vCBgYALmsj3kAIIjJAMrsEAZ5rxN076+nOrQD6lY547jnMf8K6n+CKOCFQMD75j+tR/0lwoTfaUIRT2J9IHonTW0VbWWWK1rDaVHZQJjnjrKnE1xneJqQ4L2uf6aD5JinU7FpXDP/ExkLnn+ka6vaug6dc1ZCP9M7WPvPz5qeqa2rUNbqdXqBrN24sz7t3rxGcG1T7F8ii9H2N7Watzk7QBnAnl+o+Gaeua5tdqLSmEUb1J82MjmaPgrqWo6z0C+3WVsWRtosHG/gc/7R/Q5p+uly4XduX7zK08ci6anEY6L063p3TEqqcrVWMIh57RHxy/0tDpqgQtmqbzp8YHP9Z6DTvnTpzkMQJ4DxHrH1vXLudyUuUrHpgf/I0kkrDG23RoeEdSV0tmhuc+UZQnviaY4GCZgdAyNYlgPm2nPyvb/XM3HbzHt+JzA9sPUK6ChofS+dh94mDkx/QjC5mtPZka0Os2SFjNYwBE6jusj3YCVQgwp47SSKfKJI4oHEgJE7mV7wAMj8cy+Yt2l1f0nGwCk4HtDVbrcjjGOSZRFyPNiJ67UnQI16I9oBAKIRk5OPUyUn8lor4B+IdBdrtA1VV20ryB7/efLtT4Qu/4gGv0lyliMFVyp/In1bRdQTUjhTW/8yNgkfBjAKd3HkPeL3sZL4Zl9L09Wm6dVRUqhVUAIB2nLtEt1pITndywmw2motXKcfaFcItf8PHeLKKfY0XR4fxLrxpkGk09uLM5sYfyzzPTdLbqHxUu58nOOw4Heel8TdKt1WuYUHZ9TOTg8HPvNzpuhp0eiFNFajA5yOW+5mNpvRqTUUeX0ekXRIQ5zYeOPQZ7Q5aaPVNIKqmuH060HYDlnMxw+T8S0FSM8229jKGaml4qmOhmtQcU5l4dkZDWl5txHWOGUe8S0By+Y1Yf4qfeWXRMcHYSSAmcjigsn/FOEMDzKIcw6nM4BQebgzoUhyM8dpOHfHYiQHDZPvBnUOU05UEkmC1dAs8rAccg4zgw9TDggwtuNpIk6TRROjyOq01WlvSxrNiudr2EDzN6Z4/0+JfXXaqtEpF9YOV2My4zydwPf/L/AFm2dOtpJdQcHsZazp+n1BQ6ipXKHKk+hmWfp3dpm7H6vSjJXQj0y/W82XBSCuPL2Jj+bNvJ4PtNBKl2AY4HaUasbhntHhjcY02TyZozldUZwqRjgg5zwZzyKdrMBjtkxyxV2FkAx6g9pnki1T9PzMreVmHpOSVCJ2D6q9Y0hW3BBI4nldbpm0tm4nKMeDNXqwdHCBiSxy2T3/7Qt+nOo6fnaGZRwDIqdyKOH4mDW2SBNX+7AHeZ9SAHOO3eaVRVlE1QMkxnQNg49Y07f2iv7xSnyNkGE35uQjkqcnEqtCGqMyQaWhlzJHs5QsCVPxGqiCIO2rnE5UShxOAWY/TuDn9sJj1nLRnEsO2J0BmnlRmHceSJaa7JK+0eRgcdogxK6TtPEsEOQIdWUV8/1gMlj7QYRL7sDEG7859hzL7ZVkEV2UVAWxYCrKMHg4gDSV47+gOYzztO3v8AMHUwcNtG4g4YZwQftF4nbMPX0LY743A/biX05NdOAM/nMPfStmoJOcA8kcH8xZ0INiA4HYH24mdxp2V5WqMa0Y1NitxnkAQ9JAg+pg/US0DzAYMCupHpiPinrZPLDejRNnZQOTDVuqAgDv3PvM7TM11nlPM0002QNx49gYPPukjqwats7vHuZI0uir2jy/8AVJO+XJ9B4o/YYOupJWpvOoyQRjiBZXB5E0FRQQwGCPaXZA/JE2UZjLDt/NLizHPtGbKAew5iWrRqqyxBx2i9ACS4i7fn+abVQO0HIxPN1neGwcfM9Fo2zQp+JJS2Up0MgYQkn8TodVgnOVnFGSMxmcXQwCzdiAJGB9SIIts5ycSpYsDj1hY1BCMd/WLWuB/ErALHgmQ3lX2sOOefYxRDWrsTYg57ZxElIZROMjb9wsbLfysoilx2Fi3Yn09+8t1C2yhfqNg1Zxw3aZNeta+1lTkE+UH2mfJNJFYQbdl9WwssIAEzNRpDXgpnDHgzdr6f/eWNj8QHUkA0p2jBT0mdKW2XdVRTp1RqwdufkRy7UMmNq7j7CedGvaxfpoPNnHlm10rSuButJP5lcab0iU2ltmlVq2NYzXYD7bZIdEwOJ2avC/sz+b+HRc3uYWq8hwGOQYANcP3VA/InVtVudgJH/KaCA4+RzFtSosrKP+1hzLJq61GLcKp7E+8IEyS3kdcZGD2gB4HrJ1vStWltC/UrU8qT+4T23RL11PTqblBAcZCnuJj+JKUbTuoIBKllJ+Ix4S1Zu6RTuAG3Kj5APEytcZaNCbcTeYjOJMexiWs1IqTPrMzS+KtBfqf0y2EPzncMAESimumK4OrN587SM95akZ49QIAXK1YYMCD2PvC6bmxjnsJ35BdFbq9p3d+c4MT2pcu/arEryPWN3sd+R2HrBWADzk5k5IeJ5bxQ6CtKK2JLkEoDgt9xH+gdPWuvceX7kkQOu0+n6h1Cp6iWuqyp4/1mz0ep0R9+Mg44mdR5TL3xjoLbQTs/y5MxvFCY0LCsZLYBx3GZ6KxgPkzzfiG3ICKxzYR+MS00qIpuzH6VothVu/3nqNIvAmP0+q04IXAmxVRZ62f0EtjSRGUm2OheJIJarAP3sZJXZM49yOMPuAPscTldVBOV3/lpovpq3GCgir9Nwc1uQfbE6BDTpseZAT88zlS1BhXVSUA58vaV/T6ms5KrYPg4MshOHJUq3s3E4B5XxVe5uSpOBggn2HrN3oeh/S6ClShTC9jMtUW/xFWrgECpmAI7nIm6upsqcV2AOpOAR6THJ/ls1xWtC3Vq81kLnJB5nzarS77XZTuZnIHzzPd+K+oLpOn2FX2uQVX744xMDomgKClLFAIHrOVcjt1E1+l2aitFFmSijAx7zf6VYzrYzH2ia1fTq3bTvPAHoZTopuXV6hXIKlM/bntHbUGkIk5KzZtbkqThR8TJ1T4Dg2YrGfnEa1VlqljgfExrGCalTdwreXDdpLJPdFYxGujpU19llQHbG4HvNes/TRVQ9hg/M8Zoesj9fdWCiKXwAnbE9QNRXUhHLMOQF5MbF0LkD3WiutmBBx2z2MwGofX9RFSbhVSfOx9/QRuxNfZrMFAuncZzwdpjtG2nCVJn89/kyyjylbJOVLQfT6PaoUdo/TQqgQdI8uSMGE3kHgzQkQGBWskELTjtJOgBDkczq2t6ySTgHHsbIEX1RJY5PoJJIMDJ19CbP1i5XUVBmVx9oV73+pUvGDtzx7ySTHkWzTjejG1wGu67oNPeAagC+B6kCbK6GirmtSv2MkkbGkcky+l8/ULQScJWgUeg/dHdHUitbYBhiRJJE/cf9SurUbR8ieH8aaizT6UJUQAwOcjMkknP3IpD2szvDNNb3VBhwefzPf6VFAB9ZJJfGjPNj+AyDIglRUHlGJJJoRENW7dpZ5JIxwm4zkkkAP/Z",
          });
          setMediaUploadProgress(false);
        }
      } catch (e) {
        console.log(e);
      }
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Course Settings</CardTitle>
      </CardHeader>
      <div className="p-4">
        {mediaUploadProgress ? (
          <MediaProgressbar
            isMediaUploading={mediaUploadProgress}
            progress={mediaUploadProgressPercentage}
          />
        ) : null}
      </div>
      <CardContent>
        {courseLandingFormData?.image ? (
          <img src={courseLandingFormData.image} />
        ) : (
          <div className="flex flex-col gap-3">
            <Label>Upload Course Image</Label>
            <Input
              onChange={handleImageUploadChange}
              type="file"
              accept="image/*"
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default CourseSettings;
