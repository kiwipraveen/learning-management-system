function NotFoundPage() {
  return <div>This page doesn't exist</div>;
}

export default NotFoundPage;
