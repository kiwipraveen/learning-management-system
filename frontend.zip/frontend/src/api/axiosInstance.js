import axios from "axios";

const axiosInstance = axios.create({
  baseURL: "http://localhost:1414",
});
// "http://localhost:5000"
// http://localhost:1414/auth/register

// axiosInstance.interceptors.request.use(
//   (config) => {
//     const accessToken = JSON.parse(sessionStorage.getItem("accessToken")) || "";

//     if (accessToken) {
//       config.headers.Authorization = `Bearer ${accessToken}`;
//     }

//     return config;
//   },
//   (err) => Promise.reject(err)
// );

axiosInstance.interceptors.request.use(
  (config) => {
    const accessToken = JSON.parse(sessionStorage.getItem("accessToken")) || "";

    // Define the routes you want to exclude
    const excludedRoutes = ["/auth/register", "/auth/login"];

    // Check if the request URL matches any excluded route
    const isExcludedRoute = excludedRoutes.some(
      (route) => config.url === route
    );

    // If the route is not excluded and accessToken exists, add the authorization header
    if (accessToken && !isExcludedRoute) {
      config.headers.Authorization = `Bearer ${accessToken}`;
    }

    return config;
  },
  (err) => Promise.reject(err)
);

export default axiosInstance;
