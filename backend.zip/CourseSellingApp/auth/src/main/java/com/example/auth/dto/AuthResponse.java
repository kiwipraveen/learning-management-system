package com.example.auth.dto;


import com.example.auth.entity.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class AuthResponse {
//   private String accessToken;
    private User user;
}
