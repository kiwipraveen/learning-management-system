package com.example.order.service;

import com.example.order.exception.ApiException;
import com.example.order.model.Order;
import com.example.order.repository.OrderRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class OrderServiceImpl implements OrderService {
    private final OrderRepository orderRepository;

    public OrderServiceImpl(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    @Override
    public Order createOrder(Order order) {
        log.info("Creating order for user: {}", order.getUserId());
        order.setOrderStatus("pending");
        order.setPaymentStatus("unpaid");

        try {
            return orderRepository.save(order);
        } catch (Exception ex) {
            throw new ApiException("Failed to create order", 500);
        }
    }

    @Override
    public Order confirmOrder(Long orderId, String paymentId) {
        log.info("Confirming order ID: {}", orderId);

        Optional<Order> optionalOrder = orderRepository.findById(orderId);
        if (optionalOrder.isPresent()) {
            Order order = optionalOrder.get();
            order.setPaymentStatus("paid");
            order.setOrderStatus("confirmed");
            order.setPaymentId(paymentId);

            try {
                return orderRepository.save(order);
            } catch (Exception ex) {
                throw new ApiException("Failed to confirm order", 500);
            }
        } else {
            throw new ApiException("Order ID " + orderId + " not found", 404);
        }
    }


}
