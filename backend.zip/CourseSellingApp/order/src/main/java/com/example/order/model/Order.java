package com.example.order.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "orders")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "User ID cannot be blank")
    private String userId;

    @NotBlank(message = "User name cannot be blank")
    private String userName;

    @Email(message = "Email should be valid")
    private String userEmail;

    @NotBlank(message = "Order status cannot be blank")
    private String orderStatus;

    @NotBlank(message = "Payment method cannot be blank")
    private String paymentMethod;

    @NotBlank(message = "Payment status cannot be blank")
    private String paymentStatus;

    private LocalDateTime orderDate;

    private String paymentId;

    private String instructorId;

    private String instructorName;

    private String courseImage;

    @NotBlank(message = "Course title cannot be blank")
    private String courseTitle;

    private String courseId;

    @DecimalMin(value = "0.0", inclusive = false, message = "Course pricing must be greater than zero")
    private Double coursePricing;
}

