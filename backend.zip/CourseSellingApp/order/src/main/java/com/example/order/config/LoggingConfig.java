package com.example.order.config;

public class LoggingConfig {
}
