package com.example.order.service;
import com.example.order.exception.ApiException;
import com.example.order.model.Order;
import com.example.order.repository.OrderRepository;
import com.example.order.service.OrderServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private OrderServiceImpl orderService;

    @Test
    public void testCreateOrder() {
        Order order = new Order();
        order.setUserId("123");
        order.setCourseTitle("Spring Boot");

        when(orderRepository.save(any(Order.class))).thenReturn(order);

        Order createdOrder = orderService.createOrder(order);
        assertNotNull(createdOrder);
        assertEquals("123", createdOrder.getUserId());
    }

    @Test
    public void testConfirmOrder() {
        Order order = new Order();
        order.setId(1L);
        order.setPaymentStatus("unpaid");

        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        Order confirmedOrder = orderService.confirmOrder(1L, "PAY12345");

        assertNotNull(confirmedOrder);
        assertEquals("confirmed", confirmedOrder.getOrderStatus());
        assertEquals("paid", confirmedOrder.getPaymentStatus());
    }

    @Test
    public void testConfirmOrderNotFound() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        ApiException exception = assertThrows(ApiException.class, () -> {
            orderService.confirmOrder(1L, "PAY12345");
        });

        assertEquals("Order ID 1 not found", exception.getMessage());
    }
}
