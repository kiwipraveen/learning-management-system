package com.example.courseapp;

import com.example.courseapp.model.Course;
import com.example.courseapp.repository.CourseRepository;
import com.example.courseapp.service.CourseServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class CourseServiceTest {

    @Mock
    private CourseRepository courseRepository;

    @InjectMocks
    private CourseServiceImpl courseService;

    private Course course;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        course = new Course();
        course.setId(1L);
        course.setTitle("Test Course");
    }

    @Test
    void testAddNewCourse() {
        when(courseRepository.save(course)).thenReturn(course);
        Course savedCourse = courseService.addNewCourse(course);
        assertEquals("Test Course", savedCourse.getTitle());
    }
}
