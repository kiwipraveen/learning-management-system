package com.example.courseapp;


import com.example.courseapp.controller.CourseController;
import com.example.courseapp.model.Course;
import com.example.courseapp.service.CourseService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class CourseControllerTest {

    @InjectMocks
    private CourseController courseController;

    @Mock
    private CourseService courseService;

    private Course course;

    @BeforeEach
    void setUp() {
        course = new Course();
        course.setId(1L);
        course.setTitle("Test Course");
    }

    @Test
    void testAddCourse() {
        when(courseService.addNewCourse(course)).thenReturn(course);
        ResponseEntity<Course> response = courseController.addNewCourse(course);
        assertEquals(201, response.getStatusCodeValue());
    }
}
