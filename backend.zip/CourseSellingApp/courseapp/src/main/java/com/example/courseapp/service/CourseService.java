package com.example.courseapp.service;

import com.example.courseapp.model.Course;

import java.util.List;
import java.util.Optional;

public interface CourseService {

    Course addNewCourse(Course course);

    List<Course> getAllCourses();

    Optional<Course> getCourseById(Long id);

    Course updateCourse(Long id, Course courseDetails);
}
