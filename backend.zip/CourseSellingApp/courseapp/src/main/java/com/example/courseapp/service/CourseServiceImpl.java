package com.example.courseapp.service;

import com.example.courseapp.model.Course;
import com.example.courseapp.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseRepository courseRepository;

    @Override
    public Course addNewCourse(Course course) {
        return courseRepository.save(course);
    }

    @Override
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    @Override
    public Optional<Course> getCourseById(Long id) {
        return courseRepository.findById(id);
    }

    @Override
    public Course updateCourse(Long id, Course courseDetails) {
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        course.setInstructorId(courseDetails.getInstructorId());
        course.setInstructorName(courseDetails.getInstructorName());
        course.setTitle(courseDetails.getTitle());
        course.setDate(courseDetails.getDate());
        course.setCategory(courseDetails.getCategory());
        course.setLevel(courseDetails.getLevel());
        course.setPrimaryLanguage(courseDetails.getPrimaryLanguage());
        course.setSubtitle(courseDetails.getSubtitle());
        course.setDescription(courseDetails.getDescription());
        course.setImage(courseDetails.getImage());
        course.setWelcomeMessage(courseDetails.getWelcomeMessage());
        course.setPricing(courseDetails.getPricing());
        course.setObjectives(courseDetails.getObjectives());
        course.setIsPublished(courseDetails.getIsPublished());
        return courseRepository.save(course);
    }
}
