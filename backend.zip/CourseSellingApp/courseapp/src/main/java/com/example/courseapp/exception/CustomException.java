package com.example.courseapp.exception;


public class CustomException extends RuntimeException {

    private int statusCode;
    private String message;

    // Constructor
    public CustomException(int statusCode, String message) {
        super(message);
        this.statusCode = statusCode;
        this.message = message;
    }

    // Getter for status code
    public int getStatusCode() {
        return statusCode;
    }

    // Setter for status code
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    // Getter for message
    public String getMessage() {
        return message;
    }

    // Setter for message
    public void setMessage(String message) {
        this.message = message;
    }
}
