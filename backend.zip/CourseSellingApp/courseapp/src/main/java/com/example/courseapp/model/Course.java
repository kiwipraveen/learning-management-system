package com.example.courseapp.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import java.util.Date;
import java.util.List;

@Entity
@Data
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private String instructorId;
    private String instructorName;
    private Date date;
    @Size(min = 3, max = 100)
    private String title;
    private String category;
    private String level;
    private String primaryLanguage;
    private String subtitle;
    private String description;
    private String image;
    private String welcomeMessage;
    private Double pricing;
    private String objectives;
    private Boolean isPublished;

}


